$Env:ARM_CLIENT_ID="e4a9a0cb-b64c-4daa-8bf9-78408f66cd13"
$Env:ARM_TENANT_ID="2b387c91-acd6-4c88-a6aa-c92a96cab8b1"
$Env:ARM_SUBSCRIPTION_ID="298f2c19-014b-4195-b821-e3d8fc25c2a8"
$Env:ARM_CLIENT_SECRET="xxxxxxxxxxxxxxxxxxxxxxxxxxxxxx"