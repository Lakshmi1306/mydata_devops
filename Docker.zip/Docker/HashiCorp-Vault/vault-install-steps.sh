apt update && apt install -y unzip net-tools
wget https://releases.hashicorp.com/vault/1.12.3/vault_1.12.3_linux_amd64.zip
unzip vault_1.12.3_linux_amd64.zip
cp vault /usr/bin/vault
mkdir -p /etc/vault
mkdir -p /var/lib/vault/data
vault version
nano config.hcl
cp config.hcl /etc/vault/config.hcl
cp vault.service /etc/systemd/system/vault.service
sudo systemctl daemon-reload
sudo systemctl stop vault
sudo systemctl start vault
sudo systemctl enable vault
sudo systemctl status vault

ps -ef | grep -i vault | grep -v grep
journalctl -u vault

export VAULT_ADDR=http://52.146.32.198:8200
echo "export VAULT_ADDR=http://52.146.32.198:8200" >>~/.bashrc

https://devopscube.com/setup-hashicorp-vault-beginners-guide/

vault status
root@vault:~# vault status
Key Value
--- -----
Seal Type shamir
Initialized false
Sealed true
Total Shares 0
Threshold 0
Unseal Progress 0/0
Unseal Nonce n/a
Version 1.12.3
Build Date 2023-02-02T09:07:27Z
Storage Type file
HA Enabled false

vault operator init >/etc/vault/init.file

vault operator unseal 1K3Bf5jZsiafC5DMyP2EFfVBE7bNee/1RNt2GFh3pm2B
vault operator unseal vervY+s7xiPMEs+d6tRpgFhxWSMdaSf/Cz/WPYvvWE7i
vault operator unseal fDYu0K1U5XsrTYqvres7cOl/Q/pMOjzSqIpMWdlhwazF

Initial Root Token: hvs.tJjgSXdnst12wo9VJhtLznSO

vault status

root@vault:~# vault status
Key Value
--- -----
Seal Type shamir
Initialized true
Sealed false
Total Shares 5
Threshold 3
Version 1.12.3
Build Date 2023-02-02T09:07:27Z
Storage Type file
Cluster Name vault
Cluster ID c6d48ce8-7ce5-31ae-20a8-1e5396785a45
