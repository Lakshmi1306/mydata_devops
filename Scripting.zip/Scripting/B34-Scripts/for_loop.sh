#Type 1
for I in {1..10}; do
    echo $I
done

#Type 2
for ((i = 0; i <= 10; i++)); do
    echo $i
done
