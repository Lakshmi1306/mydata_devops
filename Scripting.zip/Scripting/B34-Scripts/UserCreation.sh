User Creation Script.
1. Check if the user already exists in the system.
2. If not, create user but username must not container any numbers.
Username must not start with any numbers but can end with numbers.
Username must start with 3 alphabets and end with 3 numbers total username is 6 chars.
3. Create a Random Password with a pattern India@{RANDOM}{SPEC}
4. For user to reset the password on the login.

cat /etc/passwd | grep -iw ubuntu10 | cut -d ":" -f1
cat /etc/passwd | grep -iw ubuntu10 | awk -F ":" '{print $1}'
sed -i "58s/.*PasswordAuthentication.*/PasswordAuthentication yes/" /etc/ssh/sshd_config
for USER in $(cat /etc/passwd | grep -i star | cut -d ":" -f1); do userdel -r $USER; done

#!/bin/bash
USER=$1
if [ $# -gt 0 ]; then
    EXISTING_USER=$(cat /etc/passwd | grep -iw $USER | cut -d ":" -f1)
    if [ "${EXISTING_USER}" = "${USER}" ]; then
        echo "The Selected User $USER already exists. Please use a diffrent username...!!"
    else
        echo "Lets Ceate User $USER"
        sudo useradd -m $USER --shell /bin/bash
        sudo mkdir -p /home/$USER/.ssh
        sudo chown -R $USER /home/$USER/
        sudo touch /home/$USER/.ssh/authorized_keys
        sudo usermod -aG sudo $USER
        echo '$USER ALL=(ALL) NOPASSWD: ALL' | sudo tee -a /etc/sudoers
        echo "Generating Random Password..."
        SPEC=$(echo '!@#$%^&*()_' | fold -w1 | shuf | head -1)
        PASS="India@${RANDOM}${SPEC}"
        echo "$USER:$PASS" | sudo chpasswd
        echo "Login Username is $USER and Password is $PASS"
        passwd -e $USER
    fi
else
    echo "You Have Given $# Arguments. Please Provide Valid Input."
fi
