#!/bin/bash
FILE=$1
if [ -f $FILE ]; then
    echo "FILE EXISTS"
    if [ -w $FILE ]; then
        echo "I HAVE READ & WRITE ACCESS TO $FILE"
    fi
    if [ -s $FILE ]; then
        echo "FILE SIZE IS"
        du -h /etc/passwd | awk -F " " '{print $1}'
    fi
else
    echo "LETS CREATE NEW FILE"
fi

find / -size +10M -size -20M 2>/dev/null | sort | tail -n 5

for FILE in $(find / -size +10M -size -20M 2>/dev/null | sort | tail -n 5); do
    du -h $FILE
done
