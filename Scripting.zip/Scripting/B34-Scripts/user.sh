#!/bin/bash
for USER in ubuntu10 ubuntu100 ubuntu1000 ubuntu10000; do
    sudo useradd -m $USER --shell /bin/bash
done
