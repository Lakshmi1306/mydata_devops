#!/bin/bash

if [ $# -gt 0 ]; then
    PACKAGE=$1
    service $PACKAGE status >/dev/null
    if [ $? -eq 0 ]; then
        echo "The Package $PACKAGE already installed.."
    else
        apt install -y $PACKAGE
        service $PACKAGE status
    fi
else
    echo " You Have Given $# Arguments"
fi
