#!/bin/bash
rm -rf *.zip

#T_VERSION='1.4.0'
#P_VERSION='1.8.0'
T_VERSION=$1
P_VERSION=$2

echo "Lets Download Terraform Version $T_VERSION"
wget https://releases.hashicorp.com/terraform/${T_VERSION}/terraform_${T_VERSION}_linux_amd64.zip
echo ""
echo ""
echo "Lets Packer Terraform Version $P_VERSION"
wget https://releases.hashicorp.com/packer/${P_VERSION}/packer_${P_VERSION}_linux_amd64.zip
ls -al
unzip terraform_${T_VERSION}_linux_amd64.zip && rm -rf terraform_${T_VERSION}_linux_amd64.zip
unzip packer_${P_VERSION}_linux_amd64.zip && rm -rf packer_${P_VERSION}_linux_amd64.zip
mv terraform /usr/local/bin/
mv packer /usr/local/bin/
echo $0
terraform version
packer version
