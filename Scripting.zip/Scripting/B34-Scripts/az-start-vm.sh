#!/bin/bash
VMLIST=$(az vm list | jq ".[].name" -r)
for VM in $VMLIST; do
    echo "The Name Of The VM We Want To Start Is $VM"
done


VPCLIST=$(aws ec2 describe-vpcs | jq ".Vpcs[].VpcId" -r)
for VPC in $VPCLIST; do
    echo "The Name Of The VM We Want To Start Is $VPC"
done