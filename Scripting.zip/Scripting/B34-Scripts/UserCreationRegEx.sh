#!/bin/bash
USER=$1
if [ $# -gt 0 ]; then
    EXISTING_USER=$(cat /etc/passwd | grep -iw $USER | cut -d ":" -f1)
    if [ "${EXISTING_USER}" = "${USER}" ]; then
        echo "The Selected User $USER already exists. Please use a diffrent username...!!"
    else
        #if [[ $USER =~ ^[a-zA-Z]+$ ]]; then
        #if [[ $USER =~ ^[a-zA-Z] ]]; then
        if [[ "${USER}" =~ ^[a-zA-Z][a-zA-Z][a-zA-Z][0-9][0-9][0-9]$ ]]; then
            echo "Lets Ceate User $USER"
            sudo useradd -m $USER --shell /bin/bash
            sudo mkdir -p /home/$USER/.ssh
            sudo chown -R $USER /home/$USER/
            sudo touch /home/$USER/.ssh/authorized_keys
            sudo usermod -aG sudo $USER
            echo '$USER ALL=(ALL) NOPASSWD: ALL' | sudo tee -a /etc/sudoers
            echo "Generating Random Password..."
            SPEC=$(echo '!@#$%^&*()_' | fold -w1 | shuf | head -1)
            PASS="India@${RANDOM}${SPEC}"
            echo "$USER:$PASS" | sudo chpasswd
            echo "Login Username is $USER and Password is $PASS"
            passwd -e $USER
        else
            echo "The Username must not contain otherthan Alphabets"
        fi
    fi
else
    echo "You Have Given $# Arguments. Please Provide Valid Input."
fi
