#!/bin/bash
set +x
ITEMS1=$@
ITEMS2=$*
echo $ITEMS1
for ITEM in $ITEMS1; do
    echo $ITEM
done
echo '-----------------------------'
for ITEM in $ITEMS2; do
    echo $ITEM
done
