#!/bin/bash
URL='https://releases.hashicorp.com/packer/1.8.6/packer_1.8.6_linux_amd64.zip'
STAR="MEGASTAR"
NAME='PACKAGE'
#How to dowload file from URL
wget $URL

#Create 10 Copies of the files & Give custom name
for I in {1..10}; do
    cp packer_1.8.6_linux_amd64.zip "$STAR-$NAME-$I"
done

Copy a file to 20 Servers
