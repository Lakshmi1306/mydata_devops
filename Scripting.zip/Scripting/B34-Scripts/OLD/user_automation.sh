#!/bin/bash
if [ $# -gt 0 ]; then
    NEWUSER=$1
    EXISTING_USER=$(cat /etc/passwd | grep -i -w $NEWUSER | cut -d ":" -f1)
    if [ "${EXISTING_USER}" = "${NEWUSER}" ]; then
        echo "$NEWUSER Already Exists. Please Try A Diffrent Name..."
    else
        echo "Lets Create The Newuser $NEWUSER"
        sudo useradd -m $NEWUSER --shell /bin/bash
        SPEC='!@#$%^&*()_'
        SPEC_CHAR=$(echo $SPEC | fold -w1 | shuf | head -1)
        PASSWORD="India@${RANDOM}${SPEC_CHAR}"
        echo "$NEWUSER:$PASSWORD" | sudo chpasswd
        echo "The Username is $NEWUSER and Password is $PASSWORD."
        passwd -e $NEWUSER
    fi
else
    echo "Please Provide Valid Username"
fi
