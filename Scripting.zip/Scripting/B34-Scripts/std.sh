STDIN - >0
STDOUT - >1
STDERR - >2
bash std.sh 1>/dev/null     #Redirect all stdout to /dev/null
bash std.sh 2>/dev/null     #Redirect all stderr to /dev/null
bash std.sh >/dev/null 2>&1 # Redirect both stderr & stdout to /dev/null
#!/bin/bash
ls -al
youngtiger
df -h
megastar
free
superstar
service nginx status
rebelstar
