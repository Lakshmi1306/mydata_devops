STRING = 'MALAYALAMM'
REVERSE = STRING[::-1]
if (STRING == REVERSE):
    print(f'{STRING} is PALINDROME.')
else:
    print(f'{STRING} is NON-PALINDROME.') 
