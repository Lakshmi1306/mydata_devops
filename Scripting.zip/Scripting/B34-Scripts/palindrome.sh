#!/bin/bash
STRING=$1
LEN=${#STRING}
COUNT=$(expr $LEN - 1)
REVERSE=''
#echo $COUNT
for ((i = $COUNT; i >= 0; i--)); do
    X=${STRING[@]:$i:1}
    REVERSE=$REVERSE${X}
done
if [ "${STRING}" = "${REVERSE}" ]; then
    echo "$STRING is an PALINDROME"
else
    echo "$STRING is an NOT AT ALL PALINDROME."
fi
