#!/bin/bash
INPUT=$1
if [ $INPUT = 'us-east-1' ]; then
    echo "VALID REGION"
else
    echo "INVALID REGION"
fi

if [ $INPUT != 'us-east-1' ]; then
    echo "INVALID REGION"
else
    echo "VALID REGION"
fi

#!/bin/bash
INPUT=$1
if [ -z $INPUT ]; then
    echo $INPUT
else
    echo "ITS ZERO"
fi
