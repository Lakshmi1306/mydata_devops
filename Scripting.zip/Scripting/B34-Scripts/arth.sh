#!/bin/bash
CURRENT_YEAR=2023
YOB=$1
CURRENT_AGE=$(expr $CURRENT_YEAR - $YOB)
if [ $CURRENT_AGE -lt 18 ]; then
    echo "Since your age is $CURRENT_AGE which is less than 18, you cannot drive."
elif [ $CURRENT_AGE -ge 18 -a $CURRENT_AGE -lt 45 ]; then
    echo "At your age $CURRENT_AGE , you can apply and get license"
elif [ $CURRENT_AGE -ge 45 -a $CURRENT_AGE -lt 70 ]; then
    echo "At your age $CURRENT_AGE , you can apply and get license but take driving & eye test."
elif [ $CURRENT_AGE -ge 70 -a $CURRENT_AGE -lt 120 ]; then
    echo "At your age $CURRENT_AGE , driving is risk and heavy vehicles are not allowed."
else
    echo "INVALID INPUT"
fi
