$? - of the previous command or program or script. >Exitcode
$# - of params given to the script. >Number
$@ or $* - multiple Args as a list and we can iterate them. >Take
echo ${#NAME[$@]} - of a String. >Length

#!/bin/bash
REGIONS=$*
for REGION in $REGIONS; do
    aws ec2 describe-vpcs --region $REGION | jq ".Vpcs[].VpcId" -r
done
